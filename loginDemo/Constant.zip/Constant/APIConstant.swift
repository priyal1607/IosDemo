//
//  APIConstant.swift
//  SharkID
//
//  Created by Vikram Jagad on 25/02/19.
//  Copyright © 2019 sttl. All rights reserved.
//

import UIKit

//MARK:- User Information
struct CommonAPIConstant {
    static let key_errormsg = "errormsg"
    static let key_message = "message"
    static let key_languageCode = "lang"
    static let key_resultFlag = "_resultflag"
    static let key_offset = "Offset"
    static let key_limit = "Limit"
    static let key_totalcount = "totalcount"
    static let key_document = "document"
    static let key_total_record = "total_record"
    static let key_deviceID = "deviceId"
    static let key_list = "list"
    static let key_user_id = "user_id"
    static let key_token = "token"
    static let key_title = "title"
    static let key_subject = "subject"
    static let key_PicURL = "picURL"
    static let key_data = "data"
    static let key_gallerylist = "photogalleryList"
    static let key_status = "status"
}

