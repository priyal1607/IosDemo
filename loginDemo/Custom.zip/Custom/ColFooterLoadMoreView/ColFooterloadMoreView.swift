//
//  ColFooterloadMoreView.swift
//  NWM
//
//  Created by Gunjan on 30/04/21.
//

import UIKit

class ColFooterloadMoreView: UICollectionReusableView {
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
