//
//  vwfbTwitter.swift
//  BJP
//
//  Created by STTLMac on 02/03/22.
//

import UIKit

class vwfbTwitter: UIView {
    @IBOutlet weak var vwfb: UIView!
    
    @IBOutlet weak var vwTwitter: UIView!
    @IBOutlet weak var vwshare: UIView!
   
    
    @IBOutlet weak var vwMain: UIView!
   
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    

}
